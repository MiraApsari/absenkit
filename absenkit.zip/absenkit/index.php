<?php 
	header('location:page.php?masuk');
?>