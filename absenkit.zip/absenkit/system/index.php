<?php 
//redirect ke halaman error
header('location:../page.php?error-404&not=found');
?>
